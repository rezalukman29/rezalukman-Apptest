import React from 'react';
import { Provider as PaperProvider } from 'react-native-paper';
import Main from './src/Routes';
import { NavigationContainer } from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import {AuthStackNavigator} from './src/navigators/AuthStackNavigator';
import SplashScreen from './src/screens/SplashScreen';
import {lightTheme} from './src/themes/light';
import {darkTheme} from './src/themes/dark';
import {ThemeContext} from './src/contexts/ThemeContext';
import {StatusBar} from 'react-native';
import { AppLoading } from 'expo';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import { store, persistor} from './src/redux/store/store';
import {
  useFonts,
  Ubuntu_300Light,
  Ubuntu_300Light_Italic,
  Ubuntu_400Regular,
  Ubuntu_400Regular_Italic,
  Ubuntu_500Medium,
  Ubuntu_500Medium_Italic,
  Ubuntu_700Bold,
  Ubuntu_700Bold_Italic,
} from '@expo-google-fonts/ubuntu';
import { useSelector, useDispatch } from 'react-redux';


const RootStack = createStackNavigator();

export default function App() {
  


  const [isDarkMode, setIsDarkMode] = React.useState(false);
  const switchTheme = React.useCallback(() => {
    setIsDarkMode(!isDarkMode);
  }, [isDarkMode]);


  function renderScreens() {
    
 
    return  (

      <RootStack.Screen name={'AuthStack'} component={AuthStackNavigator} />
      //  <Main /> 
    );
  }

  const [loaded] = useFonts({
    Ubuntu_400Regular: Ubuntu_400Regular,
    Ubuntu_700Bold: Ubuntu_700Bold
  });
  
  if (!loaded) {
    return null;
  }



  return (
    <PaperProvider>
         <ThemeContext.Provider value={switchTheme}>

         <StatusBar barStyle={isDarkMode ? 'light-content' : 'light-content'} />

         <NavigationContainer theme={isDarkMode ? darkTheme : lightTheme}>
         <Provider store={store}>
        <PersistGate loading={null} persistor={persistor}>
              <RootStack.Navigator
            screenOptions={{
              headerShown: false,
              animationEnabled: false,
            }}>
            {renderScreens()}
          </RootStack.Navigator>
          </PersistGate>
          </Provider>
            </NavigationContainer>
        </ThemeContext.Provider>
    </PaperProvider>
  );
}