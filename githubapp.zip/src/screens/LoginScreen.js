import React from 'react';
import {StyleSheet,View,Image,Dimensions,ToastAndroid,Alert} from 'react-native';

import {
  Layout,
  Button,
  Text,
  Section,
  SectionContent,
TextInput
} from "react-native-rapi-ui";
import {FilledButton} from '../components/FilledButton';
import {Error} from '../components/Error';
import {AuthContainer} from '../components/AuthContainer';
import {Loading} from '../components/Loading';
import { ThemeContext } from '../contexts/ThemeContext';
import { useTheme } from '@react-navigation/native';
import InputText from '../components/InputText.js';
import { IconInput } from '../components/IconInput';
import ButtonSubmit from '../components/ButtonSubmit';
import { IconButton } from '../components/IconButton';
import { width,height } from '../components/Dimensions.js';

const LoginScreen = ({navigation}) => {
  const {colors} = useTheme();
  const switchTheme = React.useContext(ThemeContext);


 
  const [username, setUsername] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState('');


  const githubLogin = (username,password) => {
      if (username === '') {
        Alert.alert("Fill Username")
      } else {
        navigation.navigate('GithubLogin',{username: username})
      }

  }




  return (
   
          <Layout style={styles.container}>
           <Section>
              <SectionContent style={styles.sectionContent}>
                  <Text style={styles.titleLogin}>Login Page</Text>
                 
                  <Text style={{ marginBottom: 6 ,alignSelf: 'flex-start'}}>Username</Text>
                  <InputText
                    placeholder="Enter your Username"
                    value={username}
                    onChangeText={(val) => setUsername(val)}
                    rightContent={
                        <IconInput name={"nutrition-sharp"}/>
                    }
                />
 <Text style={{ marginBottom: 6 ,alignSelf: 'flex-start',marginTop: 12}}>Password</Text>
                  <InputText
                    placeholder="Enter your password"
                    value={password}
                    onChangeText={(val) => setPassword(val)}
                    rightContent={
                        <IconInput name={"lock-closed"}/>
                    }
                  />
                  <ButtonSubmit 
                    text="Login"
                    rightContent={
                      <IconButton name={"lock-closed"}/>
                  }
                  width={width * 1 - 36}
                  color={colors.primary}
                
                  />

<ButtonSubmit 
                    text="Login With Github"
                    rightContent={
                      <IconButton name={"logo-github"}/>
                  }
                  width={width * 1 - 36}
                  color={colors.text}
                  onPress={() => githubLogin(username,password)}
                  />

              </SectionContent>
          </Section>
            </Layout>

  );
}

export default LoginScreen;

const styles = StyleSheet.create({
  container: {
   
  },
  sectionContent: {
    alignItems: 'center',
    width: width * 1,
    marginRight: 24
  },
  titleLogin: {
    marginBottom: 50,
  
  }
});
