import React, { useEffect } from 'react';
import {
    Layout,
    Button,
    Text,
    Section,
    SectionContent,
  TextInput
  } from "react-native-rapi-ui";
  import InputText from '../components/InputText.js';
  import { IconInput } from '../components/IconInput';
  import ButtonSubmit from '../components/ButtonSubmit';
  import { IconButton } from '../components/IconButton';
  import {StyleSheet,View,Image,Dimensions,ToastAndroid,Alert} from 'react-native';
  import { ThemeContext } from '../contexts/ThemeContext';
import { useTheme } from '@react-navigation/native';
import { useSelector, useDispatch } from 'react-redux';
import { width,height } from '../components/Dimensions.js';
import { logout} from '../redux/actions/authAction';
import { Avatar } from 'react-native-rapi-ui';
import { getRepo } from '../redux/actions/repoAction.js';



export default function HomeScreen ({navigation,route}){
    const dispatch = useDispatch();
    const { user,error} = useSelector(state => state.auth);
    const { repo,message,isFetching} = useSelector(state => state.repo);
    const [repository, setRepository] = React.useState('facebook/react-native');
    const {colors} = useTheme();

    function showToast() {
      ToastAndroid.show( message, ToastAndroid.SHORT);
    }


    const setRepo = (repository) => {
        if (repository === '') {
          Alert.alert("Fill Repository")
        } else {
          dispatch(getRepo(repository))
        }
        // navigation.navigate('Repo',{repository:  repository})
    }



    useEffect(() => {
        showToast();
        console.log(isFetching)
    
      
    },[message])

    return(

        <Layout style={styles.container}>
        <Section>
           <SectionContent style={styles.sectionContent}>
               <Text style={styles.titleLogin}>Welcome {user.login}</Text>
               <Avatar
                    source={{ uri: user.avatar_url }}
                    size="xl"
                    shape="round"
                />
              
               <Text style={{ marginBottom: 6 ,alignSelf: 'flex-start'}}>Repository Name</Text>
               <InputText
                 placeholder="Type Repository"
                 value={repository}
                 onChangeText={(val) => setRepository(val)}
                 rightContent={
                     <IconInput name={"document"}/>
                 }
               />
                <ButtonSubmit 
                    text="Open Repository"
                    rightContent={
                      <IconButton name={"logo-github"}/>
                    }
                    width={width * 1 - 36}
                    color={colors.text}
                    onPress={() => setRepo(repository)}
                  />    
                <Text style={styles.logout} onPress={() => dispatch(logout())}>Log Out</Text>
                {/* <Text style={styles.logout} >{JSON.stringify(repo)}</Text> */}
            


           </SectionContent>
       </Section>
         </Layout>

    )

}

const styles = StyleSheet.create({
    container: {
     
    },
    sectionContent: {
      alignItems: 'center',
      width: width * 1,
      marginRight: 24
    },
    titleLogin: {
      marginBottom: 12,
    
    },
    logout: {
        marginTop: 12
    }
    
  });
  