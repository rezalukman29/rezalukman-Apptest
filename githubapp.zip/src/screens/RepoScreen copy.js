import React from 'react';
import {
    Layout,
    Button,
    Text,
    Section,
    SectionContent,
  TextInput
  } from "react-native-rapi-ui";
  import InputText from '../components/InputText.js';
  import { IconInput } from '../components/IconInput';
  import ButtonSubmit from '../components/ButtonSubmit';
  import { IconButton } from '../components/IconButton';
  import {StyleSheet,View,Image,Dimensions,ToastAndroid,Alert,FlatList} from 'react-native';
  import { ThemeContext } from '../contexts/ThemeContext';
import { useTheme } from '@react-navigation/native';
import { useSelector, useDispatch } from 'react-redux';
import { width,height } from '../components/Dimensions.js';
import { logout} from '../redux/actions/authAction';
import { Avatar } from 'react-native-rapi-ui';
import { getRepo } from '../redux/actions/repoAction.js';
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler';



export default function RepoScreen ({navigation}){
    const dispatch = useDispatch();
    const { user,error} = useSelector(state => state.auth);
    const { repo} = useSelector(state => state.repo);
    const [repository, setRepository] = React.useState('facebook/react-native');
    const {colors} = useTheme();
    // const setRepo = (repository) => {
    //     if (repository === '') {
    //       Alert.alert("Fill Repository")
    //     } else {
    //       dispatch(getRepo(repository))
    //       navigation.navigate('Repo')
    //     }
        
 
    // }

    const ItemSeparatorView = () => {
      return (
        // Flat List Item Separator
        <View
          style={{
            height: 0.5,
            width: '100%',
            backgroundColor: '#C8C8C8',
            alignSelf: 'center'
          }}
        />
      );
    };

    const ItemView = ({item},index) => {

      return (
        <View style={styles.listItem} key={index}>
          <View style={{flexDirection: 'row'}}>
            <Avatar
                    source={{ uri: item.committer.avatar_url }}
                    size="md"
                    shape="round"
                />
        <View style={{left: 6}}>
          <View style={{flexDirection: 'row',justifyContent: 'space-between'}}>
          <Text style={{fontWeight:"bold",fontSize: 14}}>{item.commit.author.name}</Text>
          <Text style={{fontWeight:"bold",fontSize: 11}}>{item.commit.author.date}</Text>
          </View>
          <Text style={{fontSize: 10}}>{item.commit.message}</Text>
        </View>
        </View>
      
      </View>
      );
    };
  
   
    return(

        <View style={styles.container}>
        <Section>
           <SectionContent style={styles.sectionContent}>
             <View style={{flexDirection: 'row'}}>
                {/* <Avatar
                    source={{ uri: user.avatar_url }}
                    size="sm"
                    shape="round"
                /> */}
               <Text style={styles.titleLogin}> {user.login}</Text>
             </View>
             <ScrollView>
             <FlatList
                
                data={repo}
                // ItemSeparatorComponent={ItemSeparatorView}
                renderItem={ItemView}
                keyExtractor={(sha,index) => { sha.toString(); }}
            />
              </ScrollView>
                <Text style={styles.logout} onPress={() => dispatch(logout())}>Logout</Text>
            


           </SectionContent>
       </Section>
         </View>

    )

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',

  },
    sectionContent: {
      marginTop: 36,
      alignItems: 'center',
      width: width * 1,
      // marginRight: 24
    },
    titleLogin: {
      marginBottom: 12,top: 3
    
    },
    logout: {
        marginTop: 12
    },
    productsListContainer: {

      // paddingVertical: 8,
      // marginHorizontal: 8,
    },

    infoContainerReview: {
      // padding: 10,
      marginBottom: 30
    },

    title: {
      fontSize: 14,
      right: 10,
      top: -5,fontWeight: 'bold'
    },
    caption: {
      fontSize: 12,
      right: 10,
      top: -5,
      textAlign: 'justify',width: width * 0.85
    },

    listItem:{

      backgroundColor:"#FFF",
      width: width * 1,
      // flex:1,
      alignSelf:"center",
      flexDirection:"row",
      borderRadius:5,
 
    }
    
  });
  