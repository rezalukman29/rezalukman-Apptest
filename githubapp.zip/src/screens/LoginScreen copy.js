import React from 'react';
import {StyleSheet,View,Image} from 'react-native';

import {
  Layout,
  Button,
  Text,
  Section,
  SectionContent,
  useTheme,
} from "react-native-rapi-ui";

import {FilledButton} from '../components/FilledButton';
import {Error} from '../components/Error';
import {AuthContainer} from '../components/AuthContainer';

import {Loading} from '../components/Loading';

import { ThemeContext } from '../contexts/ThemeContext';
import OutlinedInput from '../components/OutlinedInput';



const LoginScreen = ({navigation}) => {

  const switchTheme = React.useContext(ThemeContext);


 
  const [email, setEmail] = React.useState('lukman.reza@gmail.com');
  const [password, setPassword] = React.useState('Kwzwa88saa');
  const [loading, setLoading] = React.useState(false);
  const [error, setError] = React.useState('');

  // React.useLayoutEffect(() => {
  //   navigation.setOptions({
  //     headerRight: () => (
  //       <HeaderIconsContainer>
  //         <HeaderIconButton
  //           name={'color-palette'}
  //           onPress={() => {
  //             switchTheme();
  //           }}
  //         />
 
  //       </HeaderIconsContainer>
  //     ),
  //   });
  // }, [navigation,  switchTheme]);

  return (
    <AuthContainer>
  
         {/* <Image
        style={{width: 350,height: 200}}
        source={require('../assets/Wander_light.png')}
      /> */}




      <View style={{marginBottom: -50}}/>
 
      <Error error={error} />

      <OutlinedInput 
      mode="outlined"
      label="Email"
      placeholder=""
      
      value={email}
      onChangeText={setEmail}
      style={{bottom: 100}}
    />

      <OutlinedInput 
      mode="outlined"
      label="Password"
      placeholder="Type something"
      secureTextEntry
      value={password}
      onChangeText={setPassword}
    />
      <FilledButton
      name="login"
        title={'SIGN IN'}
        style={styles.loginButton}
        // onPress={async () => {
        //   try {
        //     setLoading(true);
        //     await login(email, password);
        //     console.log('email :', email)
        //     console.log('pass :', password)
        //   } catch (e) {
        //     setError(e.message);
        //     setLoading(false);
        //   }
        // }}
      />

{/* 
      <TextButton
        title={'SIGN UP'}
        onPress={() => {
          navigation.navigate('Register');
        }}
      /> */}

    
      <Loading loading={loading} />
 <View style={{marginBottom: 100}}></View>
    </AuthContainer>
  );
}

export default LoginScreen;

const styles = StyleSheet.create({
  title: {
    marginBottom: 48,
  },
  input: {
    marginVertical: 8,
  },
  loginButton: {
    marginVertical: 32,
  },
});
