import React from 'react';
import {StyleSheet,View,Image,Dimensions,ToastAndroid,Alert} from 'react-native';

import {
  Layout,
  Button,
  Text,
  Section,
  SectionContent,
TextInput
} from "react-native-rapi-ui";
import {FilledButton} from '../components/FilledButton';
import {Error} from '../components/Error';
import {AuthContainer} from '../components/AuthContainer';
import {Loading} from '../components/Loading';
import { ThemeContext } from '../contexts/ThemeContext';
import { useTheme } from '@react-navigation/native';
import InputText from '../components/InputText.js';
import { IconInput } from '../components/IconInput';
import ButtonSubmit from '../components/ButtonSubmit';
import { IconButton } from '../components/IconButton';
import { useSelector, useDispatch } from 'react-redux';
import { login} from '../redux/actions/authAction';
import { width,height } from '../components/Dimensions.js';

const GithubLogin = ({navigation,route}) => {
  const {colors} = useTheme();
  const switchTheme = React.useContext(ThemeContext);
  const { user,error} = useSelector(state => state.auth);


 
  const username = route.params.username
  const [password, setPassword] = React.useState('');
  const [loading, setLoading] = React.useState(false);

  const dispatch = useDispatch();

  const githubLogin = (username,password) => {
      if (password === '') {
        Alert.alert("Fill Password")
      } else {
        var loginData = {
          username: username,
          password: password
        }

        dispatch(login(loginData))
      }
      
     


  
  }




  return (
   
          <Layout style={styles.container}>
           <Section>
              <SectionContent style={styles.sectionContent}>
                  <Text style={styles.titleLogin}>Login With Github {user.username}</Text>
              
                 
                  <Text style={{ marginBottom: 6 ,alignSelf: 'center'}}>{username}</Text>
               
                  <Text style={{ marginBottom: 6 ,alignSelf: 'flex-start',marginTop: 12}}>Password</Text>
                  <InputText
                    placeholder="Enter your password"
                    value={password}
                    onChangeText={(val) => setPassword(val)}
                    rightContent={
                        <IconInput name={"lock-closed"}/>
                    }
                  />
              

                  <ButtonSubmit 
                    text="Login With Github"
                    rightContent={
                      <IconButton name={"logo-github"}/>
                    }
                    width={width * 1 - 36}
                    color={colors.text}
                    onPress={() => githubLogin(username,password)}
                  />

              </SectionContent>
          </Section>
            </Layout>

  );
}

export default GithubLogin;

const styles = StyleSheet.create({
  container: {
   
  },
  sectionContent: {
    alignItems: 'center',
    width: width * 1,
    marginRight: 24
  },
  titleLogin: {
    marginBottom: 50,
  
  }
});
