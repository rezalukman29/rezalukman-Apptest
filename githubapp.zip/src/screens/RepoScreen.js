import React, { useEffect } from 'react';
import {
    Layout,
    Button,
    Text,
    Section,
    SectionContent,
  TextInput
  } from "react-native-rapi-ui";
import InputText from '../components/InputText.js';
import { IconInput } from '../components/IconInput';
import ButtonSubmit from '../components/ButtonSubmit';
import { IconButton } from '../components/IconButton';
import {StyleSheet,View,Image,Dimensions,ToastAndroid,Alert,FlatList} from 'react-native';
import { ThemeContext } from '../contexts/ThemeContext';
import { useTheme } from '@react-navigation/native';
import { useSelector, useDispatch } from 'react-redux';
import { width,height } from '../components/Dimensions.js';
import { logout} from '../redux/actions/authAction';
import { Avatar } from 'react-native-rapi-ui';
import { getRepo } from '../redux/actions/repoAction.js';
import { ScrollView, TouchableOpacity } from 'react-native-gesture-handler';


const CARD_WIDTH = width * 0.85;


export default function RepoScreen ({navigation,route}){
    const repository = route.params.repository
    const dispatch = useDispatch();
    const { user,error} = useSelector(state => state.auth);
    const { repo} = useSelector(state => state.repo);
    const {colors} = useTheme();

    function showToast() {
      ToastAndroid.show( repository + ' Loaded Succesfully', ToastAndroid.SHORT);
    }

    useEffect(() => {
      showToast()
    },[])

    const ItemView = ({item},index) => {

      return (
        <View key={index} style={styles.card}>
          
          <View style={{flexDirection: 'row'}}>
          <Avatar
                  source={{ uri: item.committer.avatar_url }}
                  size="md"
                  shape="round"
              />
          <View style={{flexDirection: 'column',top: 6}}>
            <Text style={{fontSize: 13,fontWeight: 'bold',paddingHorizontal: 6}}>{item.commit.author.name}</Text>
            {/* <Text style={{fontSize: 11,fontWeight: '100',width: width * 0.72,paddingHorizontal: 6}}>{item.commit.message}</Text> */}
            <Text style={styles.textDate}>{item.commit.author.date}</Text>
          </View>
          
          </View>
          <Text style={{fontSize: 11,fontWeight: '100',width: width * 0.8,paddingHorizontal: 6,marginTop: 6}}>{item.commit.message}</Text>
   
        </View>
      );
    };
   
    return(

      <Layout style={styles.container}>
      <Section>
         <SectionContent style={styles.sectionContent}>
           <View style={{flexDirection: 'row',alignSelf: 'flex-start',marginBottom: 6}}>
           <Avatar
                  source={{ uri: user.avatar_url }}
                  size="sm"
                  shape="round"
              />
             <Text style={styles.titleLogin}> {user.login}</Text>
        
          </View>
          <Text style={styles.titleRepository}> {repository}</Text>
            
        
          <View style={{alignSelf: 'flex-start'}}>
   
             <FlatList
                
                data={repo}
                renderItem={ItemView}
                keyExtractor={(sha,index) => { sha.toString(); }}

            />

 

          </View>
      

         </SectionContent>
     </Section>
       </Layout>


    )

}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',

  },
    sectionContent: {
    
      alignItems: 'center',
      // width: width * 1,
      marginTop: 24
    },
    titleLogin: {
      marginBottom: 6,top: 3
    
    },
    titleRepository: {
     marginBottom: 3
    
    },
    logout: {
        marginTop: 12
    },
    productsListContainer: {

      // paddingVertical: 8,
      // marginHorizontal: 8,
    },

    infoContainerReview: {
      // padding: 10,
      marginBottom: 30
    },

    title: {
      fontSize: 14,
      right: 10,
      top: -5,fontWeight: 'bold'
    },
    caption: {
      fontSize: 12,
      right: 10,
      top: -5,
      textAlign: 'justify',width: width * 0.85
    },

    textDate: {
      fontSize: 10,
      fontWeight: '100',
      width: width * 0.8,
      paddingHorizontal: 6,
      fontStyle: 'italic',
  
    },
    card: {
      padding: 6,
      marginVertical: 6,
      elevation: 5,
      backgroundColor: '#fff',
      borderRadius: 12,
      marginHorizontal: 6,
      shadowColor: '#000',
      shadowRadius: 5,
      shadowOpacity: 0.3,
      shadowOffset: {x:2,y:-2},
      width: CARD_WIDTH,
      flexDirection: 'column'
   
    }
    
  });
  