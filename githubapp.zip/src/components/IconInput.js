import React from 'react';

import { Ionicons } from '@expo/vector-icons';
import {useTheme} from '@react-navigation/native';

export function IconInput({name}) {
  const {colors} = useTheme();
  return (
 
      <Ionicons  name={name} color={colors.primary} size={20} />
  
  );
}

