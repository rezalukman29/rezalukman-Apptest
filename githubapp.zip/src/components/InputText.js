import { useTheme } from '@react-navigation/native';
import * as React from 'react';
import {
      TextInput
} from "react-native-rapi-ui";
import { Ionicons } from '@expo/vector-icons';
import {StyleSheet,View,Image,Dimensions} from 'react-native';

const InputText = (props,name) => {
    const {colors} = useTheme();
  return (

        <TextInput
          placeholder={props.placeholder}
          value={props.value}
          onChangeText={(val) => props.onChangeText(val)}
          rightContent={props.rightContent}
      
    />
   
  );
};

export default InputText;