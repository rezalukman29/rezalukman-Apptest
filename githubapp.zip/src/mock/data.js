export const userList = [
    {
      email: "lukman.reza@gmail.com",
      password: "Asli2021",
      avatar: "https://asset.kompas.com/crops/DZ3y2iEuToTYRT07qWvy5LhQ39k=/64x0:600x357/750x500/data/photo/2021/09/11/613cbf8997887.jpeg",
      username: "rezalukman29"
    },

  ];

  export const repository = [
    {
      title: "Nodejs With Fun"
    },
    {
      title: "Laravel Backend"
    },

  ];
  
  