import React from 'react';
import {createStackNavigator} from '@react-navigation/stack';

import LoginScreen from '../screens/LoginScreen';
import {ThemeContext } from '../contexts/ThemeContext';
import {useTheme} from '@react-navigation/native'
import GithubLogin from '../screens/GithubLogin';


const AuthStack = createStackNavigator();
// const LoginStack = createStackNavigator();

export function AuthStackNavigator() {
  const switchTheme = React.useContext(ThemeContext);
  const {colors} = useTheme();
  return (
    <AuthStack.Navigator
      mode={'modal'}
      screenOptions={{
        headerShown: false,
      }}
      initialRouteName="Login"
      >
     
            <AuthStack.Screen name={'Login'} component={LoginScreen} options={{
          title:'',
          headerStyle: {
            backgroundColor: colors.background,
            elevation: 0,
            shadowOffset: {
              height: 0,
          },
          shadowRadius: 0,
          },
          headerRight: null,

          }}/>

<AuthStack.Screen name={'GithubLogin'} component={GithubLogin} options={{
          title:'',
          headerStyle: {
            backgroundColor: colors.background,
            elevation: 0,
            shadowOffset: {
              height: 0,
          },
          shadowRadius: 0,
          },
          headerRight: null,

          }}/>



  

      
    </AuthStack.Navigator>
  );
}
