import { SET_LOGIN_STATE,LOGIN_LOADING,LOGIN_ERROR, SET_LOGOUT } from '../actions/authAction';

const initialStateAuth = {
    user: '',
    error: '',
    isLoading: false,
    isLogin: false
   

  };

  function authReducer(state = initialStateAuth, action) {
    switch (action.type) {
      case SET_LOGIN_STATE:
        
        return { ...state, 
          user: action.payload,
          error: 'Login Success' ,
          isLoading: false,
          isLogin: true
              };

              case LOGIN_LOADING:
        
                return { ...state, 
                  user: '',
                  // error: action.payload ,
                  isLoading: action.payload
                      };

                      case LOGIN_ERROR:
                
                        return { ...state, 
                          user: '',
                          error: action.payload ,
                          isLoading: false
                              };

                              case SET_LOGOUT:
                
                                return { ...state, 
                                  user: '',
                                  error: action.payload ,
                                  isLoading: false,
                                  isLogin: false
                                      };

       
        

      default:
        return state;
    }
  }

  export default authReducer;