import { GET_REPO_REQUEST,GET_REPO_SUCCESS,GET_REPO_ERROR } from '../actions/repoAction';

const initialStateRepo = {
   repo: [],
   isLoading: false,
   message: '',
   isFetching: false
   

  };

  function repoReducer(state = initialStateRepo, action) {
    switch (action.type) {
      case GET_REPO_REQUEST:
        
        return { ...state, 
          message: 'Loading...' ,
          isFetching: false,
         
              };

              case GET_REPO_SUCCESS:
        
                return { ...state, 
                  repo: action.payload,
                  isFetching: true,
                      };

                      case GET_REPO_ERROR:
                
                        return { ...state, 
                          message: action.payload ,
                          isFetching: false
                              };

                             
       
        

      default:
        return state;
    }
  }

  export default repoReducer;