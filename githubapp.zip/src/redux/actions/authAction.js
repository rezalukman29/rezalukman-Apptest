


export const SET_LOGIN_STATE = 'SET_LOGIN_STATE';
export const LOGIN_LOADING = 'LOGIN_LOADING';
export const LOGIN_ERROR = 'LOGIN_ERROR';
export const SET_LOGOUT = 'SET_LOGOUT';

export const login = (loginData) => async dispatch => {

console.log("usernamme :", loginData.username)
        try {
    
          const fetchPromise =  fetch(`https://api.github.com/users/` + loginData.username , {
            method: 'GET',
            headers: {
              Accept: "application/json, text/plain, */*",
              "Content-Type": "application/json;charset=UTF-8",
              "cache-control": "public, max-age=60, s-maxage=60",
              "vary" : "Accept, Accept-Encoding, Accept, X-Requested-With",
              "x-github-media-type": "github.v3; format=json",
              "access-control-expose-headers": "ETag, Link, Location, Retry-After, X-GitHub-OTP, X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Used, X-RateLimit-Resource, X-RateLimit-Reset, X-OAuth-Scopes, X-Accepted-OAuth-Scopes, X-Poll-Interval, X-GitHub-Media-Type, Deprecation, Sunset",
              "access-control-allow-origin": "*",
              "strict-transport-security": "max-age=31536000; includeSubdomains; preload"
            },
            // body: JSON.stringify(formData)
          })
            fetchPromise.then(response => {
                return response.json();
            }).then(account => {
                console.log(account);
       
               dispatch({
                type: SET_LOGIN_STATE,
                payload: account
              });
    
          
          });
       

     
    
    } catch (error) {
      // Add custom logic to handle errors
      // AsyncStorage.removeItem('user')
    //   dispatch({
    //     type: LOGIN_ERROR,
    //     payload: 'Login Error'
    //   });
    }
  };




  export const logout = () => {

    return async dispatch => {

    
 
      dispatch({
        type: SET_LOGOUT,
        payload: 'Anda Telah Logout'
      });
};
};