


export const GET_REPO_REQUEST = 'GET_REPO_REQUEST';
export const GET_REPO_SUCCESS = 'GET_REPO_SUCCESS';
export const GET_REPO_ERROR = 'GET_REPO_ERROR';



export const getRepo = (repository) => async dispatch => {

      dispatch({
        type: GET_REPO_REQUEST,
     
      });
        try {
        
        
          const fetchPromise =  fetch(`https://api.github.com/repos/` + repository + `/commits` , {
            method: 'GET',
            headers: {
              Accept: "application/json, text/plain, */*",
              "Content-Type": "application/json;charset=UTF-8",
              "cache-control": "public, max-age=60, s-maxage=60",
              "vary" : "Accept, Accept-Encoding, Accept, X-Requested-With",
              "x-github-media-type": "github.v3; format=json",
              "access-control-expose-headers": "ETag, Link, Location, Retry-After, X-GitHub-OTP, X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Used, X-RateLimit-Resource, X-RateLimit-Reset, X-OAuth-Scopes, X-Accepted-OAuth-Scopes, X-Poll-Interval, X-GitHub-Media-Type, Deprecation, Sunset",
              "access-control-allow-origin": "*",
              "strict-transport-security": "max-age=31536000; includeSubdomains; preload"
            },
           
          })
            fetchPromise.then(response => {
                return response.json();
            }).then(repo => {
             
             if (repo !== undefined && repo.length > 0) {
          
              dispatch({
                type: GET_REPO_SUCCESS,
                payload: repo
              })
        
             } else {
              dispatch({
                type: GET_REPO_ERROR,
                payload: repository + 'is Not Found'
              })
             }
       
          
    
            })
        
       

     
    
    } catch (error) {
      dispatch({
        type: GET_REPO_ERROR,
        // payload: repo
      });
    }
  };




  export const logout = () => {

    return async dispatch => {

    
 
      dispatch({
        type: SET_LOGOUT,
        payload: 'Anda Telah Logout'
      });
};
};